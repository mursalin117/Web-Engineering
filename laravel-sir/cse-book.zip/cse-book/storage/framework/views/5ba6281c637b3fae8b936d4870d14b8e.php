<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
<h1>listAllBooks</h1>

    <table width="100%" border="1">
        <thead>
        <tr>
            <td>ID</td>
            <td>isbn</td>
            <td>title</td>
            <td>author</td>
            <td>stock</td>
            <td>price</td>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($book->id); ?></td>
                <td><?php echo e($book->isbn); ?></td>
                <td><?php echo e($book->title); ?></td>
                <td><?php echo e($book->author); ?></td>
                <td><?php echo e($book->stock); ?></td>
                <td><?php echo e($book->price); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>

    </table>




</body>
</html>
<?php /**PATH /Users/kushal/Sites/cse-book/resources/views/books/list_all.blade.php ENDPATH**/ ?>